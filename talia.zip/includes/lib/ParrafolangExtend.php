<?php
    
      class ParrafolangExtend extends Parrafolang
      {
         public function __construct(){
		   parent::__construct();
		 }
         
         //implement methods here
      }
    