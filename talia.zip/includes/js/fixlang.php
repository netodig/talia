<script language="javascript">
MENSAJE_REQUERIDO="Campo requerido";
MENSAJE_NUMBER="Debe ser número";
EMAIL_INVALIDO="Email invalido";
EMAIL_Y_CONFIRMACION_IGUALES="El email y su confirmación deben ser iguales";
CLAVE_Y_CONFIRMACION_IGUALES="La clave y su confirmación deben ser iguales";
CLAVE_8_CARACTERES="";
</script>