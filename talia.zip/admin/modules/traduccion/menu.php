<li>
	<a href="javascript:void(0)">Traducciones</a>
    <ul>
 
      	<li><a href="<?php echo Url::adminlink("traduccion/traduce/tablas") ?>">Configuración</a></li>
    
        <li><a href="<?php echo Url::adminlink("traduccion/traduce/traduce") ?>">Traducir</a></li>
      </ul>
</li>