<?php
    
      class PerfilPermisosExtend extends PerfilPermisos
      {
        
      }
    